# Design Guidelines: Allo-SportsHub

## Design Approach
**Reference-Based Design** drawing from leading sports media platforms (ESPN, The Athletic, Bleacher Report) combined with modern content platforms (Medium, Notion). Focus on bold typography, dynamic imagery, and clear content hierarchy that emphasizes the excitement of sports content while maintaining professional readability.

## Typography System

**Headlines & Hero Content:**
- Primary Font: Inter or Roboto (700-900 weight) for impact
- Hero Headlines: text-5xl to text-7xl, font-bold
- Article Titles: text-3xl to text-4xl, font-bold
- Section Headers: text-2xl, font-semibold

**Body & Interface:**
- Body Font: Inter or system-ui (400-500 weight)
- Article Content: text-lg, leading-relaxed, max-w-prose
- Navigation/UI: text-sm to text-base, font-medium
- Metadata (dates, authors): text-sm, font-normal

## Layout System

**Spacing Primitives:** Use Tailwind units of 4, 6, 8, 12, and 16 consistently
- Section padding: py-16 to py-24
- Card/component gaps: gap-6 to gap-8
- Container max-width: max-w-7xl
- Content reading width: max-w-4xl

**Grid Structure:**
- Featured Articles: 2-column layout (lg:grid-cols-2)
- Article Grid: 3-column on desktop (lg:grid-cols-3), 2-column tablet (md:grid-cols-2), single-column mobile
- Sidebar layouts: 2/3 main content + 1/3 sidebar pattern

## Component Library

**Navigation Header:**
- Sticky top navigation with logo left, main nav center, auth controls right
- Search bar prominently placed in header
- Category dropdown/mega-menu for sports categories
- "Write Article" CTA button (visible only to authenticated authors)

**Hero Section:**
- Full-width hero with large featured article image (aspect-ratio: 21/9)
- Overlay gradient for text readability
- Hero content: Category tag, headline, author byline, CTA
- Buttons on images use backdrop-blur-md bg-white/20 treatment

**Article Cards:**
- Card structure: Image (aspect-ratio: 16/9), category tag, headline, excerpt, author/date metadata
- Hover effect: subtle scale transform and shadow increase
- Author avatar + name displayed prominently

**Authentication UI:**
- Modal-based login/signup forms
- Clear role indication: "Author Dashboard" vs "Reader View"
- Profile dropdown in header showing user role

**Search Interface:**
- Search bar with icon, expandable on mobile
- Live search results dropdown with article previews
- Filter options: by category, by author, by date

**Author Dashboard (Authenticated Authors Only):**
- "My Articles" management panel
- Create/Edit article editor with rich text capabilities
- Draft/Published status indicators
- Article analytics preview

**Article Detail Page:**
- Full-width hero image for article
- Author card with bio and social links
- Related articles section (3-column grid)
- Share buttons, read time indicator

**Footer:**
- 4-column layout: About, Categories, Quick Links, Newsletter signup
- Social media icons
- Copyright and legal links

## Images Strategy

**Primary Images Required:**

1. **Hero Section:** Large sports action shot showcasing energy and movement (1920x800px recommended)
2. **Article Cards:** Each article needs a featured image (800x450px minimum)
3. **Category Headers:** Sport-specific imagery for each category page
4. **Author Avatars:** Profile photos for all authors
5. **About/Team Section:** Team photos or brand imagery

**Image Treatment:**
- All article images use rounded corners (rounded-lg)
- Hero images have dark gradient overlay (from-black/60 to-transparent)
- Lazy loading for performance
- Maintain 16:9 aspect ratio for consistency

**Placeholder Strategy:** Use Unsplash or Pexels sports photography for initial development

## Key UX Patterns

**Content Prioritization:**
- Featured/trending articles prominently displayed above fold
- Category filtering accessible without scrolling
- Latest articles in chronological feed

**Author-Specific Features:**
- Role-based UI: Show "Write Article" and dashboard only to authenticated authors
- Visual distinction between author and visitor views
- Quick access to personal article management

**Search Functionality:**
- Instant search with debouncing
- Search across titles, content, and author names
- Clear visual feedback for search results

**Responsive Behavior:**
- Mobile-first approach with hamburger menu
- Collapsible sidebar on tablets
- Touch-friendly tap targets (minimum 44px)

## Visual Hierarchy Principles

- Bold, large imagery creates immediate impact
- Typography scale creates clear information hierarchy
- White space separates content sections effectively
- Category tags use subtle background colors for quick scanning
- Author attribution always visible but secondary to content
- CTAs use high contrast and clear labeling

**No color specifications provided** - colors will be defined in subsequent design phase.

Set-Alias psql "C:\Program Files\PostgreSQL\18\bin\psql.exe"