import { RequestHandler } from "express";
import { verifyToken } from "../auth/jwt";

export const requireAuth: RequestHandler = (req, res, next) => {
  const token = req.cookies?.auth;

  if (!token) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const payload = verifyToken(token);

    req.user = {
      id: payload.userId,
      role: payload.role,
    };

    next();
  } catch {
    return res.status(401).json({ message: "Unauthorized" });
  }
};