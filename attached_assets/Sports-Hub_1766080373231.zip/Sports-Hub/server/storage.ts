import {
  articles,
  type Article,
  type InsertArticle,
  type UpdateArticle,
  type ArticleWithAuthor,
} from "@shared/schema";
import { users } from "@shared/models/auth";
import { db } from "./db";
import { eq, ilike, or, desc, and } from "drizzle-orm";

/**
 * Slugify helper
 */
function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

export interface IStorage {
  getArticles(): Promise<ArticleWithAuthor[]>;
  getPublishedArticles(): Promise<ArticleWithAuthor[]>;
  getArticleById(id: string): Promise<ArticleWithAuthor | undefined>;
  getArticlesByAuthor(authorId: string): Promise<ArticleWithAuthor[]>;
  searchArticles(query: string): Promise<ArticleWithAuthor[]>;
  createArticle(article: InsertArticle): Promise<Article>;
  updateArticle(id: string, article: UpdateArticle): Promise<Article | undefined>;
  deleteArticle(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  /**
   * Attach author info to an article
   */
private async withAuthor(article: Article): Promise<ArticleWithAuthor> {
  const [author] = await db
    .select()
    .from(users)
    .where(eq(users.id, article.authorId));

  return {
    ...article,

    // 🔥 NORMALISATION CRITIQUE
    published: article.published ?? false,
    featured: article.featured ?? false,

    author: {
      id: author?.id ?? article.authorId,
      firstName: author?.firstName ?? null,
      lastName: author?.lastName ?? null,
      profileImageUrl: author?.profileImageUrl ?? null,
    },
  };
}

  /**
   * Get ALL articles (admin / dashboard)
   */
  async getArticles(): Promise<ArticleWithAuthor[]> {
    const rows = await db
      .select()
      .from(articles)
      .orderBy(desc(articles.createdAt));

    return Promise.all(rows.map((a) => this.withAuthor(a)));
  }

  /**
   * Get ONLY published articles (public)
   */
  async getPublishedArticles(): Promise<ArticleWithAuthor[]> {
    const rows = await db
      .select()
      .from(articles)
      .where(eq(articles.published, true))
      .orderBy(desc(articles.createdAt));

    return Promise.all(rows.map((a) => this.withAuthor(a)));
  }

  /**
   * Get article by ID
   */
  async getArticleById(id: string): Promise<ArticleWithAuthor | undefined> {
    const [row] = await db
      .select()
      .from(articles)
      .where(eq(articles.id, id));

    if (!row) return undefined;
    return this.withAuthor(row);
  }

  /**
   * Get articles by author
   */
  async getArticlesByAuthor(authorId: string): Promise<ArticleWithAuthor[]> {
    const rows = await db
      .select()
      .from(articles)
      .where(eq(articles.authorId, authorId))
      .orderBy(desc(articles.createdAt));

    return Promise.all(rows.map((a) => this.withAuthor(a)));
  }

  /**
   * Search published articles
   */
  async searchArticles(query: string): Promise<ArticleWithAuthor[]> {
    const q = `%${query}%`;

    const rows = await db
      .select()
      .from(articles)
      .where(
        and(
          eq(articles.published, true),
          or(
            ilike(articles.title, q),
            ilike(articles.excerpt, q),
            ilike(articles.content, q),
            ilike(articles.category, q)
          )
        )
      )
      .orderBy(desc(articles.createdAt));

    return Promise.all(rows.map((a) => this.withAuthor(a)));
  }

  /**
   * Create article
   */
  async createArticle(article: InsertArticle): Promise<Article> {
    const slug = slugify(article.title);

    const [created] = await db
      .insert(articles)
      .values({
        ...article,
        slug,
        published: article.published ?? false,
        featured: article.featured ?? false,
      })
      .returning();

    return created;
  }

  /**
   * Update article
   */
  async updateArticle(
    id: string,
    articleData: UpdateArticle
  ): Promise<Article | undefined> {
    const data: UpdateArticle & { updatedAt: Date } = {
      ...articleData,
      updatedAt: new Date(),
    };

    // If title changes → regenerate slug
    if ("title" in articleData && articleData.title) {
  (data as any).slug = slugify(articleData.title);
}

    const [updated] = await db
      .update(articles)
      .set(data)
      .where(eq(articles.id, id))
      .returning();

    return updated;
  }

  /**
   * Delete article
   */
  async deleteArticle(id: string): Promise<boolean> {
    const result = await db
      .delete(articles)
      .where(eq(articles.id, id))
      .returning();

    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();