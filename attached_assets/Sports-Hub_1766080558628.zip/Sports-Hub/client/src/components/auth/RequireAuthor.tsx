import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

export function RequireAuthor({ children }: { children: JSX.Element }) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) return null;

  if (!user) {
    setLocation("/login");
    return null;
  }

  if (user.role !== "AUTHOR" && user.role !== "ADMIN") {
    setLocation("/");
    return null;
  }

  return children;
}