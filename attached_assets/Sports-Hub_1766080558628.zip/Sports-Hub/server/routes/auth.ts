import type { Express } from "express";
import bcrypt from "bcryptjs";
import { db } from "../db";
import { users } from "@shared/models/auth";
import { eq } from "drizzle-orm";
import { signToken, verifyToken } from "../auth/jwt";

export function registerAuthRoutes(app: Express) {
  /**
   * REGISTER
   */
  app.post("/api/auth/register", async (req, res) => {
    const { email, password, firstName, lastName } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Missing fields" });
    }

    try {
      const passwordHash = await bcrypt.hash(password, 10);

      const [user] = await db
        .insert(users)
        .values({
          email,
          passwordHash,
          firstName,
          lastName,
          role: "USER", // rôle par défaut
        })
        .returning();

      const token = signToken({
  userId: user.id,
  role: user.role as "USER" | "AUTHOR" | "ADMIN",
});

      res.cookie("auth", token, {
        httpOnly: true,
        sameSite: "lax",
        secure: false, // true en prod HTTPS
        path: "/",
      });

      // ❗ ne jamais renvoyer le hash
      const { passwordHash: _, ...safeUser } = user;

      res.status(201).json(safeUser);
    } catch (error) {
      res.status(409).json({ message: "Email already exists" });
    }
  });

  /**
   * LOGIN
   */
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Missing credentials" });
    }

    const user = await db.query.users.findFirst({
      where: eq(users.email, email),
    });

    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = signToken({
  userId: user.id,
  role: user.role as "USER" | "AUTHOR" | "ADMIN",
});

    res.cookie("auth", token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      path: "/",
    });

    const { passwordHash: _, ...safeUser } = user;
    res.json(safeUser);
  });

  /**
   * LOGOUT
   */
  app.post("/api/auth/logout", (_req, res) => {
    res.clearCookie("auth", { path: "/" });
    res.status(200).json({ success: true });
  });

  /**
   * CURRENT USER
   * utilisé par useAuth()
   */
  app.get("/api/auth/user", async (req: any, res) => {
    const token = req.cookies?.auth;

    if (!token) {
      return res.status(401).json(null);
    }

    try {
      const { userId } = verifyToken(token);

      const user = await db.query.users.findFirst({
        where: eq(users.id, userId),
      });

      if (!user) {
        return res.status(401).json(null);
      }

      const { passwordHash: _, ...safeUser } = user;
      res.json(safeUser);
    } catch {
      res.status(401).json(null);
    }
  });
}