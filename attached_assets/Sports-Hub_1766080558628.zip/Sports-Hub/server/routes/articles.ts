import type { Express } from "express";
import { db } from "../db";
import { articles, users } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export function registerArticleRoutes(app: Express) {
  // GET all published articles
  app.get("/api/articles", async (_req, res) => {
    try {
      const results = await db
        .select({
          id: articles.id,
          title: articles.title,
          excerpt: articles.excerpt,
          category: articles.category,
          imageUrl: articles.imageUrl,
          createdAt: articles.createdAt,
          author: {
            id: users.id,
            firstName: users.firstName,
            lastName: users.lastName,
            profileImageUrl: users.profileImageUrl,
          },
        })
        .from(articles)
        .leftJoin(users, eq(articles.authorId, users.id))
        .where(eq(articles.published, true))
        .orderBy(desc(articles.createdAt));

      res.json(results);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  // GET single article by slug
  app.get("/api/articles/:slug", async (req, res) => {
    try {
      const { slug } = req.params;

      const [article] = await db
        .select({
          id: articles.id,
          title: articles.title,
          content: articles.content,
          excerpt: articles.excerpt,
          category: articles.category,
          imageUrl: articles.imageUrl,
          createdAt: articles.createdAt,
          author: {
            id: users.id,
            firstName: users.firstName,
            lastName: users.lastName,
            profileImageUrl: users.profileImageUrl,
          },
        })
        .from(articles)
        .leftJoin(users, eq(articles.authorId, users.id))
        .where(eq(articles.slug, slug));

      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }

      res.json(article);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });
}