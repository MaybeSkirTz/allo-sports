import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { insertArticleSchema, updateArticleSchema } from "@shared/schema";

import { registerArticleRoutes } from "./routes/articles";
import { registerAuthRoutes } from "./routes/auth";

import { requireAuth } from "./middleware/requireAuth";
import { requireRole } from "./middleware/requireRole";

function slugify(text: string) {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .substring(0, 150);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Auth routes (JWT)
  registerAuthRoutes(app);

  // Article-specific routes
  registerArticleRoutes(app);

  // -------------------------
  // PUBLIC ROUTES
  // -------------------------

  app.get("/api/articles", async (_req, res) => {
    const articles = await storage.getPublishedArticles();
    res.json(articles);
  });

  app.get("/api/articles/search", async (req, res) => {
    const query = req.query.q as string;
    if (!query || query.length < 2) return res.json([]);
    const articles = await storage.searchArticles(query);
    res.json(articles);
  });

  app.get("/api/articles/:id", async (req, res) => {
    const article = await storage.getArticleById(req.params.id);
    if (!article) return res.status(404).json({ message: "Article not found" });
    res.json(article);
  });

  // -------------------------
  // PROTECTED ROUTES (AUTHOR)
  // -------------------------

  app.get(
    "/api/articles/my",
    requireAuth,
    requireRole("AUTHOR"),
    async (req: any, res) => {
      const articles = await storage.getArticlesByAuthor(req.user.id);
      res.json(articles);
    }
  );

  app.post(
    "/api/articles",
    requireAuth,
    requireRole("AUTHOR"),
    async (req: any, res) => {
      const parseResult = insertArticleSchema.safeParse({
  ...req.body,
  slug: slugify(req.body.title),
  authorId: req.user.id,
});

      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }

      const article = await storage.createArticle(parseResult.data);
      res.status(201).json(article);
    }
  );

  app.patch(
    "/api/articles/:id",
    requireAuth,
    requireRole("AUTHOR"),
    async (req: any, res) => {
      const article = await storage.getArticleById(req.params.id);

      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }

      if (article.authorId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const parseResult = updateArticleSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }

      const updated = await storage.updateArticle(
        req.params.id,
        parseResult.data
      );

      res.json(updated);
    }
  );

  app.delete(
    "/api/articles/:id",
    requireAuth,
    requireRole("AUTHOR"),
    async (req: any, res) => {
      const article = await storage.getArticleById(req.params.id);

      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }

      if (article.authorId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deleteArticle(req.params.id);
      res.status(204).send();
    }
  );

  return httpServer;
}