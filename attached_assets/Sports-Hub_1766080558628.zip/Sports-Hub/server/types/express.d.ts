import "express";

declare global {
  namespace Express {
    interface User {
      id: string;
      role: "USER" | "AUTHOR" | "ADMIN";
    }

    interface Request {
      user?: User;
    }
  }
}

export {};