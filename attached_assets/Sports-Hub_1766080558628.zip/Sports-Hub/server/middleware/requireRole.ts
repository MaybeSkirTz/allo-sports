import { RequestHandler } from "express";

export const requireRole = (
  role: "AUTHOR" | "ADMIN"
): RequestHandler => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    if (req.user.role === "ADMIN") {
      return next();
    }

    if (req.user.role !== role) {
      return res.status(403).json({ message: "Forbidden" });
    }

    next();
  };
};