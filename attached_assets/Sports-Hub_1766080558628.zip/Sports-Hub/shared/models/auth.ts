import { sql } from "drizzle-orm";
import {
  pgTable,
  varchar,
  timestamp,
} from "drizzle-orm/pg-core";

// Users table (JWT auth, roles-based)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),

  email: varchar("email", { length: 255 }).notNull().unique(),

  passwordHash: varchar("password_hash", { length: 255 }).notNull(),

  firstName: varchar("first_name", { length: 100 }),
  lastName: varchar("last_name", { length: 100 }),
  profileImageUrl: varchar("profile_image_url"),

  // USER | AUTHOR | ADMIN
  role: varchar("role", { length: 20 }).notNull().default("USER"),

  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type InsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;